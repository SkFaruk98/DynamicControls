sap.ui.define([
	"project1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
